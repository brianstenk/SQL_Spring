--SELECT getDate()


--Note that in the  Update SQL statement
--You can have a  �From�  clause (in T-SQL)!

  --1)  Add all deposits to the balance.  Get a total balance per account.
 --In Class Question1
   SELECT AccNbr, SUM (amount) AS SumDepositsPerAcc
   INTO #DaysDeposits
   FROM Deposits
   GROUP BY accNbr

  -- SELECT * FROM #DaysDeposits

   UPDATE BankAcc 
   SET balance = balance + SumDepositsPerAcc
   		   FROM #DaysDeposits dd INNER JOIN BankAcc ac
           ON  dd.accNbr = ac.accNbr
   --SELECT * FROM BankAcc 


--2)  Subtract all withdrawals from the balance.  Get a total balance per account.
-- select * from Withdraws
   SELECT accNbr, SUM (amount) AS Withdraws
   INTO #DaysWithdraws
   FROM Deposits
   GROUP BY AccNbr
  
  -- select * from #DaysWithdraws
 -- select accNbr, ROUND(balance, 2) as Bal, clientID from BankAcc
   UPDATE BankAcc 
   SET balance = balance - Withdraws 
		   FROM #DaysWithdraws dw INNER JOIN BankAcc b
           ON dw.accNbr = b.accNbr


--3)  Add the daily interest to the account.  Assume  2%  interest per year.  So, the daily interest is  balance * (0.02/365)  

UPDATE BankAcc 
   SET balance = balance + balance * (0.02/365)


--Homework : 
--1)  How get sum of all deposits for each client? --On assumption of different accounts 
		SELECT cl.name, d.accNbr, d.amount, bc.balance, bc.clientID
		FROM Deposits d LEFT JOIN  BankAcc bc 
		ON d.accNbr = bc.accNbr
		JOIN Client cl 
		ON cl.ClientID = bc.clientID
		GROUP BY d.accNbr

		SELECT bc.clientID, cl.name, SUM(d.amount) AS TotalDeposit
		--INTO #AccountDeposits
		FROM Deposits d LEFT JOIN BankAcc bc 
		ON d.accNbr = bc.accNbr JOIN Client cl ON cl.ClientID =bc.clientID
		GROUP BY bc.clientID, cl.name

--2)  How get sum of all withdrawals for each client?
        SELECT accNbr, SUM(amount) AS Withdraws
		INTO #TotalWithraw2
		FROM Withdraws
		GROUP BY accNbr

	

		SELECT accNbr, balance, cl.clientID 
		INTO #4
		FROM BankAcc ba INNER JOIN Client cl
		ON ba.clientID = cl.ClientID

		SELECT ClientID, SUM(Withdraws) AS Total_WithByClient
		FROM #TotalWithraw2 tw INNER JOIN #4 bc
		ON tw.accNbr = bc.accNbr
		GROUP BY ClientID

--Extra Credit : 
--Test this on a real database.  Create the four tables, put in some data, and test it!
--Done
